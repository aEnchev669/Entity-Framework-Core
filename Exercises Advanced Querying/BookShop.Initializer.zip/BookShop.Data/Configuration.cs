﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=ALEKS\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
