﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=ALEKS\SQLEXPRESS;Database=Cadastre;Trusted_Connection=True";
    }
}
