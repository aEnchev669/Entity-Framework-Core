﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=ALEKS\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
